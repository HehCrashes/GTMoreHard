package com.hehcrashes.gtmorehard.common.block;

public interface IHasMoreBlockInfo {

    boolean isNoMobSpawn();

    boolean isNotTileEntity();

}
