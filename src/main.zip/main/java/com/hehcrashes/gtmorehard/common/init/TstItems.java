package com.hehcrashes.gtmorehard.common.init;

import com.hehcrashes.gtmorehard.common.item.ItemAdder01;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;

public class TstItems {

    public static final ItemAdder01 MetaItem01 = new ItemAdder01();

}
